﻿namespace Mesap.Framework.Diagnostics
{
    public enum PerformanceCounterType
    {
        /// <summary>
        /// Ein unmittelbarer Indikator, der den zuletzt beobachteten Wert im Hexadezimalformat
        /// anzeigt. Wird z. B. verwendet, um einen einfachen Zähler für Elemente oder
        /// Operationen zu verwalten.
        /// </summary>
        NumberOfItemsHex32 = 0,
        /// <summary>
        /// Ein unmittelbarer Indikator, der den zuletzt beobachteten Wert anzeigt. Wird
        /// z. B. verwendet, um einen einfachen Zähler für eine sehr große Anzahl von
        /// Elementen oder Operationen zu verwalten. Er unterscheidet sich von NumberOfItemsHEX32
        /// nur dadurch, dass er größere Felder verwendet, um größere Werte verarbeiten
        /// zu können.
        /// </summary>
        NumberOfItemsHex64 = 256,
        /// <summary>
        ///Ein unmittelbarer Indikator, der den zuletzt beobachteten Wert anzeigt. Wird
        ///z. B. verwendet, um einen einfachen Zähler für Elemente oder Operationen
        ///zu verwalten.
        /// </summary>
        NumberOfItems32 = 65536,
        /// <summary>
        ///Ein unmittelbarer Indikator, der den zuletzt beobachteten Wert anzeigt. Wird
        ///z. B. verwendet, um einen einfachen Zähler für eine sehr große Anzahl von
        ///Elementen oder Operationen zu verwalten. Er unterscheidet sich von NumberOfItems32
        ///nur dadurch, dass er größere Felder verwendet, um größere Werte verarbeiten
        ///zu können.
        /// </summary>
        NumberOfItems64 = 65792,
        /// <summary>
        ///Ein Differenzindikator, der die Änderung des gemessenen Attributs zwischen
        ///den beiden letzten Messintervallen anzeigt.
        /// </summary>
        CounterDelta32 = 4195328,
        /// <summary>
        ///Ein Differenzindikator, der die Änderung des gemessenen Attributs zwischen
        ///den beiden letzten Messintervallen anzeigt. Er unterscheidet sich vom CounterDelta32-Indikatortyp
        ///nur dadurch, dass er größere Felder verwendet, um größere Werte verarbeiten
        ///zu können.
        /// </summary>
        CounterDelta64 = 4195584,
        /// <summary>
        ///Ein Durchschnittsindikator, der die durchschnittliche Anzahl der in einer
        ///Sekunde durchgeführten Operationen anzeigt. Bei einem Indikator dieses Typs
        ///ergibt eine Samplingabtastung entweder 1 oder 0. Bei den Indikatordaten handelt
        ///es sich um die Anzahl der gemessenen Einsen. Die Zeiteinheit ist dabei ein
        ///Tick des Systemzeitgebers.
        /// </summary>
        SampleCounter = 4260864,
        /// <summary>
        ///Ein Durchschnittsindikator, der die durchschnittliche Länge einer Warteschlange
        ///für eine Ressource über einen Zeitraum wiedergibt. Er zeigt den Quotienten
        ///aus der Differenz der während der letzten zwei Messintervalle beobachteten
        ///Warteschlangenlängen und der Dauer des Intervalls an. Dieser Typ eines Indikators
        ///wird i. d. R. zum Überwachen der Anzahl der Elemente verwendet, die sich
        ///in der Warteschlange oder im Wartezustand befinden.
        /// </summary>
        CountPerTimeInterval32 = 4523008,
        /// <summary>
        ///Ein Durchschnittsindikator, der die durchschnittliche Länge einer Warteschlange
        ///für eine Ressource über einen Zeitraum wiedergibt. Zähler dieses Typs zeigen
        ///den Quotienten aus der Differenz der während der letzten zwei Messintervalle
        ///beobachteten Warteschlangenlängen und der Dauer des Intervalls an. Dieser
        ///Indikatortyp unterscheidet sich von CountPerTimeInterval32 nur dadurch, dass
        ///er größere Felder verwendet, um größere Werte verarbeiten zu können. Dieser
        ///Typ eines Indikators wird i. d. R. zum Überwachen umfangreicher oder sehr
        ///zahlreicher Elemente verwendet, die sich in der Warteschlange oder im Wartezustand
        ///befinden.
        /// </summary>
        CountPerTimeInterval64 = 4523264,
        /// <summary>
        ///Ein Differenzindikator, der die mittlere Anzahl der pro Sekunde des Messintervalls
        ///durchgeführten Operationen anzeigt. Indikatoren dieses Typs messen die Zeit
        ///in Ticks der Systemuhr.
        /// </summary>
        RateOfCountsPerSecond32 = 272696320,
        /// <summary>
        ///Ein Differenzindikator, der die mittlere Anzahl der pro Sekunde des Messintervalls
        ///durchgeführten Operationen anzeigt. Indikatoren dieses Typs messen die Zeit
        ///in Ticks der Systemuhr. Dieser Indikatortyp unterscheidet sich von RateOfCountsPerSecond32
        ///nur dadurch, dass er größere Felder verwendet, um größere Werte verarbeiten
        ///und eine große Anzahl von Elementen oder Operationen pro Sekunde verfolgen
        ///zu können, z. B. eine Byte-Übertragungsrate.
        /// </summary>
        RateOfCountsPerSecond64 = 272696576,
        /// <summary>
        ///Ein unmittelbarer Prozentindikator, der das Verhältnis einer Teilmenge zur
        ///zugehörigen Menge in Prozent anzeigt. Es kann z. B. die Anzahl der auf einer
        ///Festplatte verwendeten Bytes mit der Gesamtzahl der Bytes auf der Festplatte
        ///verglichen werden. Indikatoren dieses Typs zeigen keinen durchschnittlichen
        ///Wert über eine Zeitspanne an, sondern den aktuellen Prozentwert.
        /// </summary>
        RawFraction = 537003008,
        /// <summary>
        ///Ein Prozentindikator, der die mittlere Aktivitätsdauer einer Komponente als
        ///prozentualen Anteil der Gesamtdauer des Messintervalls anzeigt.
        /// </summary>
        CounterTimer = 541132032,
        /// <summary>
        ///Ein Prozentindikator, der die Aktivitätsdauer einer Komponente als prozentualen
        ///Anteil der Gesamtdauer des Messintervalls darstellt. Die Zeit wird dabei
        ///in Einheiten von 100 Nanosekunden (ns) gemessen. Zeiger dieses Typs sind
        ///zur Messung der Aktivität einer einzelnen Komponente vorgesehen.
        /// </summary>
        Timer100Ns = 542180608,
        /// <summary>
        ///Ein Prozentindikator, der das durchschnittliche Verhältnis der Anzahl der
        ///Erfolge und der Gesamtzahl der Operationen während der letzten zwei Messintervalle
        ///angibt.
        /// </summary>
        SampleFraction = 549585920,
        /// <summary>
        ///Ein Prozentindikator, der den durchschnittlichen prozentualen Anteil der
        ///während eines Messintervalls beobachteten Aktivitätsdauer anzeigt. Der Wert
        ///dieser Indikatoren wird berechnet, indem der prozentuale Anteil der Aktivitätsdauer
        ///des Dienstes von 100 Prozent subtrahiert wird.
        /// </summary>
        CounterTimerInverse = 557909248,
        /// <summary>
        ///Ein Prozentindikator, der den durchschnittlichen prozentualen Anteil der
        ///während eines Messintervalls beobachteten Aktivitätsdauer anzeigt.
        /// </summary>
        Timer100NsInverse = 558957824,
        /// <summary>
        ///Ein Prozentindikator, der die Aktivitätsdauer mindestens einer Komponente
        ///als prozentualen Teil der Gesamtdauer des Messintervalls darstellt. Da der
        ///Zähler die Aktivitätsdauer von gleichzeitig aktiven Komponenten angibt, kann
        ///das prozentuale Ergebnis 100 Prozent überschreiten.
        /// </summary>
        CounterMultiTimer = 574686464,
        /// <summary>
        ///Ein Prozentindikator, der die Aktivitätsdauer mindestens einer Komponente
        ///als prozentualen Teil der Gesamtdauer des Messintervalls anzeigt. Die Zeit
        ///wird dabei in Einheiten von 100 Nanosekunden (ns) gemessen.
        /// </summary>
        CounterMultiTimer100Ns = 575735040,
        /// <summary>
        ///Ein Prozentindikator, der die Aktivitätsdauer mindestens einer Komponente
        ///als prozentualen Teil der Gesamtdauer des Messintervalls anzeigt. Die Aktivitätszeit
        ///wird ermittelt, indem die Zeit gemessen wird, in der die Komponenten nicht
        ///aktiv waren, und das Ergebnis vom Produkt von 100 Prozent mit der Anzahl
        ///der überwachten Objekte subtrahiert wird.
        /// </summary>
        CounterMultiTimerInverse = 591463680,
        /// <summary>
        ///Ein Prozentindikator, der die Aktivitätsdauer mindestens einer Komponente
        ///als prozentualen Teil der Gesamtdauer des Messintervalls anzeigt. Die Zeit
        ///wird bei diesem Indikatortyp in Einheiten von 100 Nanosekunden (ns) gemessen.
        ///Die Aktivitätszeit wird ermittelt, indem die Zeit gemessen wird, in der die
        ///Komponenten nicht aktiv waren, und das Ergebnis vom Produkt von 100 Prozent
        ///mit der Anzahl der überwachten Objekte subtrahiert wird.
        /// </summary>
        CounterMultiTimer100NsInverse = 592512256,
        /// <summary>
        ///Ein Durchschnittsindikator, der die durchschnittliche Dauer eines Prozesses
        ///oder einer Operation angibt. Indikatoren dieses Typs geben das Verhältnis
        ///der Gesamtdauer des Messintervalls und der Anzahl der während dieser Zeit
        ///durchgeführten Prozesse oder Operationen an. Dieser Indikatortyp misst die
        ///Zeit in Ticks der Systemuhr.
        /// </summary>
        AverageTimer32 = 805438464,
        /// <summary>
        ///Ein Differenzzeitgeber, der die Gesamtzeit zwischen dem Startzeitpunkt der
        ///Komponente oder des Prozesses und dem Zeitpunkt der Berechnung dieses Werts
        ///anzeigt.
        /// </summary>
        ElapsedTime = 807666944,
        /// <summary>
        ///Ein Durchschnittsindikator, der die durchschnittliche Anzahl der während
        ///einer Operation verarbeiteten Elemente anzeigt. Indikatoren dieses Typs zeigen
        ///das Verhältnis der verarbeiteten Elemente und der Anzahl der durchgeführten
        ///Operationen an. Dieses Verhältnis wird durch Vergleich der Anzahl der innerhalb
        ///des letzten Zeitintervalls verarbeiteten Elemente mit der Anzahl der in diesem
        ///Intervall durchgeführten Operationen berechnet.
        /// </summary>
        AverageCount64 = 1073874176,
        /// <summary>
        ///Ein Basisindikator, der die Anzahl der Samplingabtastungen speichert und
        ///als Nenner der Samplingbruchzahl verwendet wird. Die Samplingbruchzahl ist
        ///die Anzahl der Messungen, die für eine Messabtastung 1 (oder true) ergeben
        ///haben. Stellen Sie sicher, dass dieser Wert größer als 0 ist, bevor Sie ihn
        ///in einer Berechnung von SampleCounter oder SampleFraction als Nenner verwenden.
        /// </summary>
        SampleBase = 1073939457,
        /// <summary>
        ///Ein Basiszähler, der für die Berechnung der Durchschnittswerte von Zeit oder
        ///Anzahl verwendet wird, z. B. AverageTimer32 und AverageCount64. Speichert
        ///den Nenner für die Berechnung eines Indikators, um "Zeit pro Operation" oder
        ///"Anzahl pro Operation" auszugeben.
        /// </summary>
        AverageBase = 1073939458,
        /// <summary>
        ///Ein Basisindikator, in dem der Nenner eines Indikators gespeichert wird,
        ///der einen arithmetischen Bruch darstellt. Stellen Sie sicher, dass dieser
        ///Wert größer als 0 ist, bevor Sie ihn als Nenner in einer RawFraction-Wertberechnung
        ///verwenden.
        /// </summary>
        RawBase = 1073939459,
        /// <summary>
        ///Ein Basisindikator, der die Anzahl der gemessenen Elemente angibt. Er wird
        ///als Nenner bei Durchschnittsberechnungen von Zeitwerten für mehrere gleichartige
        ///Elemente verwendet. Wird mit CounterMultiTimer, CounterMultiTimerInverse,
        ///CounterMultiTimer100Ns und CounterMultiTimer100NsInverse verwendet.
        /// </summary>
        CounterMultiBase = 1107494144,
    }
}
