using System.Collections.Generic;
using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using PostSharp.Aspects;
using PostSharp.Aspects.Configuration;
using PostSharp.Extensibility;
using PostSharp.Reflection;

namespace Mesap.Framework.Diagnostics
{
    [Serializable]
    //[DebuggerNonUserCode]  //<-- Comment out this, to enable debugging
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
//    [ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
//    [AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
//    [AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
//    [AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 100)]
    public abstract class PerformanceCounterAttribute : OnMethodBoundaryAspect
    {
        private static PerformanceCounterDescriptions s_Descriptions;

        protected readonly string m_CounterName;

        [NonSerialized]
        PerformanceCounter m_Counter;

        [NonSerialized]
        protected bool m_IsFailure;

        ValueProvider m_DefaultValueProvider;
        protected virtual ValueProvider ValueProvider
        {
            get { return m_DefaultValueProvider ?? (m_DefaultValueProvider = new ConstantValueProvider(0)); }
        }
        PerformanceCounterWriter m_DefaultPerformanceCounterWriter;
        protected virtual PerformanceCounterWriter PerformanceCounterWriter
        {
            get { return m_DefaultPerformanceCounterWriter ?? (m_DefaultPerformanceCounterWriter = new DefaultPerformanceCounterWriter()); }
        }

        public static void Initialize(PerformanceCounterDescriptions descriptions)
        {
            s_Descriptions = descriptions;
        }

        protected PerformanceCounterAttribute(string counterName)
        {
            m_CounterName = counterName;
        }

        public override bool CompileTimeValidate(MethodBase method)
        {
            if (!base.CompileTimeValidate(method))
            {
                return false;
            }

            if (string.IsNullOrEmpty(m_CounterName))
            {
                Message.Write(SeverityType.Error, "TA001", "Counter name is empty");
                return false;
            }
            return true;
        }

        public override void RuntimeInitialize(MethodBase method)
        {
            base.RuntimeInitialize(method);

            if (s_Descriptions == null)
            {
                SetFailureAndWarn("PerformanceCounterAttribute not intialized. Performance counters used in attributes won't work");
                return;
            }

            PerformanceCounterDescription description;
            if (!s_Descriptions.TryGetDescription(m_CounterName, out description))
            {
                SetFailureAndWarn(string.Format("No description for performance counter {0} found. Add to descriptions or check spelling of counter name in attribute", m_CounterName));
            }
            else
            {
                try
                {
                    m_Counter = AttachedPerformanceCounters.Get(s_Descriptions.Category, s_Descriptions.CategoryHelp, s_Descriptions.Instance, description);

                    if (!m_Counter.IsValid)
                    {
                        SetFailureAndWarn(string.Format("Failed to intialize performance counter '{0}'", m_CounterName));
                    }
                }
                catch (Exception e)
                {
                    SetFailureAndWarn(string.Format("Failed to intialize performance counter {0}", m_CounterName), e);
                }
            }
        }

        void SetFailureAndWarn(string warning, Exception e = null)
        {
            var log = new Log<PerformanceCounterAttribute>();
            if (e == null)
            {
                log.Warning(warning);
            }
            else
            {
                log.Warning(warning, e);
            }

            m_IsFailure = true;
        }

        public override void OnExit(MethodExecutionArgs args)
        {
            base.OnExit(args);

            if (!m_IsFailure && m_Counter != null)
            {
                try
                {
                    long value;
                    if (ValueProvider.TryGetValue(args.Instance, args.ReturnValue, args.Arguments, out value))
                    {
                        PerformanceCounterWriter.Update(m_Counter, value);
                    }
                }
                catch (Exception e)
                {
                    var log = new Log<PerformanceCounterAttribute>();
                    log.Warning("OnExit threw exception. Performance counter {0} disabled", e, m_CounterName);
                    m_IsFailure = true;
                }
            }
        }
    }

    [Serializable]
    public abstract class ValueProvider
    {
        public abstract bool TryGetValue(object instance, object returnValue, Arguments arguments, out long value);

        protected static long GetCountOrNumberValue(object value)
        {
            long numberValue = 0;
            if (value is IEnumerable)
            {
                var enumerable = (IEnumerable)value;
                numberValue = enumerable.Cast<object>().Count();
            }
            else if (value != null)
            {
                numberValue = Convert.ToInt64(value);
            }
            return numberValue;
        }
    }

    [Serializable]
    public abstract class PerformanceCounterWriter
    {
        public abstract void Update(PerformanceCounter counter, long value);
    }

    [Serializable]
    public class DefaultPerformanceCounterWriter : PerformanceCounterWriter
    {
        public override void Update(PerformanceCounter counter, long value)
        {
            counter.RawValue = value;
        }
    }

    [Serializable]
    public class IncrementPerformanceCounterWriter : PerformanceCounterWriter
    {
        readonly int m_Increment;

        public IncrementPerformanceCounterWriter(int increment)
        {
            m_Increment = increment;
        }

        public override void Update(PerformanceCounter counter, long value)
        {
            counter.IncrementBy(m_Increment);
        }
    }

    [Serializable]
    public class PerMinutePerformanceCounterWriter : PerformanceCounterWriter
    {
        readonly string m_CounterName;
        readonly bool m_UpdateCounterOnly;

        public PerMinutePerformanceCounterWriter(string counterName, bool updateCounterOnly = false)
        {
            m_CounterName = counterName;
            m_UpdateCounterOnly = updateCounterOnly;
        }

        public override void Update(PerformanceCounter counter, long value)
        {
            var tracker = ValuesPerMinuteTrackers.Get(m_CounterName);
            if (!m_UpdateCounterOnly)
            {
                tracker.ValuesProcessed(value);
            }
            counter.RawValue = tracker.CurrentValue;
        }
    }

    [Serializable]
    public class MemberValueProvider : ValueProvider
    {
        readonly string m_MemberName;
        protected LocationInfo m_Member;

        public MemberValueProvider(string memberName)
        {
            m_MemberName = memberName;
        }

        public bool CompileTimeValidate(MethodBase method)
        {
            var member = method.DeclaringType.GetFieldFromType(m_MemberName);
            if (member == null)
            {
                Message.Write(SeverityType.Error, "TA001", "No member {0} on on type {1}", m_MemberName, method.DeclaringType.Name);
                return false;
            }
            return true;
        }

        public void CompileTimeInitialize(MethodBase method)
        {
            var memberInfo = method.DeclaringType.GetFieldFromType(m_MemberName);
            if (memberInfo is PropertyInfo)
            {
                m_Member = new LocationInfo((PropertyInfo)memberInfo);
            }
            else
            {
                m_Member = new LocationInfo((FieldInfo)memberInfo);
            }
        }

        public override bool TryGetValue(object instance, object returnValue, Arguments arguments, out long value)
        {
            var memberValue = m_Member.GetValue(instance);
            value = GetCountOrNumberValue(memberValue);
            return true;
        }
    }

    [Serializable]
    public class ReturnValueProvider : ValueProvider
    {
        public override bool TryGetValue(object instance, object returnValue, Arguments arguments, out long value)
        {
            value = GetCountOrNumberValue(returnValue);
            return true;
        }

        public bool CompileTimeValidate(MethodBase method)
        {
            var methodInfo = method as MethodInfo;
            if ((methodInfo == null) ||
                ((methodInfo.ReturnType != typeof(int) && methodInfo.ReturnType != typeof(long) && !typeof(IEnumerable).IsAssignableFrom(methodInfo.ReturnType))))
            {
                Message.Write(SeverityType.Error, "TA001", "Invalid attribute usage on method {0}. Attribute can only be used on methods with a int, long or IEnumerable return type", method.Name);
                return false;
            }
            return true;
        }
    }

    [Serializable]
    public class ConstantValueProvider : ValueProvider
    {
        readonly long m_Value;

        public ConstantValueProvider(long value)
        {
            m_Value = value;
        }

        public override bool TryGetValue(object instance, object returnValue, Arguments arguments, out long value)
        {
            value = m_Value;
            return true;
        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 101)]
    public class PerformanceCounterMemberAttribute : PerformanceCounterAttribute
    {
        protected LocationInfo m_Member;
        readonly MemberValueProvider m_MemberValueProvider;

        public PerformanceCounterMemberAttribute(string counterName, string memberName)
            : base(counterName)
        {
            m_MemberValueProvider = new MemberValueProvider(memberName);
        }

        protected override ValueProvider ValueProvider
        {
            get { return m_MemberValueProvider; }
        }

        public override bool CompileTimeValidate(MethodBase method)
        {
            if (!base.CompileTimeValidate(method))
            {
                return false;
            }

            return m_MemberValueProvider.CompileTimeValidate(method);
        }

        public override void CompileTimeInitialize(MethodBase method, AspectInfo aspectInfo)
        {
            m_MemberValueProvider.CompileTimeInitialize(method);
        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 102)]
    public class PerformanceCounterReturnValueAttribute : PerformanceCounterAttribute
    {
        readonly ReturnValueProvider m_ReturnValueProvider;

        public PerformanceCounterReturnValueAttribute(string counterName)
            : base(counterName)
        {
            m_ReturnValueProvider = new ReturnValueProvider();
        }

        protected override ValueProvider ValueProvider
        {
            get { return m_ReturnValueProvider; }
        }

        public override bool CompileTimeValidate(MethodBase method)
        {
            if (!base.CompileTimeValidate(method))
            {
                return false;
            }

            return m_ReturnValueProvider.CompileTimeValidate(method);
        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 103)]
    public class PerformanceCounterResetAttribute : PerformanceCounterAttribute
    {
        public PerformanceCounterResetAttribute(string counterName)
            : base(counterName)
        {

        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 104)]
    public class PerformanceCounterIncrementAttribute : PerformanceCounterAttribute
    {
        readonly IncrementPerformanceCounterWriter m_IncrementValueWriter;

        public PerformanceCounterIncrementAttribute(string counterName)
            : this(counterName, 1)
        {

        }

        public PerformanceCounterIncrementAttribute(string counterName, int increment)
            : base(counterName)
        {
            m_IncrementValueWriter = new IncrementPerformanceCounterWriter(increment);
        }

        protected override PerformanceCounterWriter PerformanceCounterWriter
        {
            get { return m_IncrementValueWriter; }
        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 105)]
    public class PerformanceCounterRatePerMinuteFromMemberAttribute : PerformanceCounterMemberAttribute
    {
        readonly PerMinutePerformanceCounterWriter m_PerMinuteCounterWriter;

        public PerformanceCounterRatePerMinuteFromMemberAttribute(string counterName, string memberName)
            : base(counterName, memberName)
        {
            m_PerMinuteCounterWriter = new PerMinutePerformanceCounterWriter(counterName);
        }

        protected override PerformanceCounterWriter PerformanceCounterWriter
        {
            get { return m_PerMinuteCounterWriter; }
        }

        public override void RuntimeInitialize(MethodBase method)
        {
            base.RuntimeInitialize(method);
            ValuesPerMinuteTrackers.AssertTrackerExists(m_CounterName);
        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 106)]
    public class PerformanceCounterRatePerMinuteFromReturnValueAttribute : PerformanceCounterReturnValueAttribute
    {
        readonly PerMinutePerformanceCounterWriter m_PerMinuteCounterWriter;

        public PerformanceCounterRatePerMinuteFromReturnValueAttribute(string counterName)
            : base(counterName)
        {
            m_PerMinuteCounterWriter = new PerMinutePerformanceCounterWriter(counterName);
        }

        protected override PerformanceCounterWriter PerformanceCounterWriter
        {
            get { return m_PerMinuteCounterWriter; }
        }

        public override void RuntimeInitialize(MethodBase method)
        {
            base.RuntimeInitialize(method);
            ValuesPerMinuteTrackers.AssertTrackerExists(m_CounterName);
        }
    }

    [Serializable]
    //[ProvideAspectRole(StandardRoles.PerformanceInstrumentation)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.ExceptionHandling)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.Tracing)]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 107)]
    public class PerformanceCounterRatePerMinuteUpdateAttribute : PerformanceCounterAttribute
    {
        readonly PerMinutePerformanceCounterWriter m_PerMinuteCounterWriter;

        public PerformanceCounterRatePerMinuteUpdateAttribute(string counterName)
            : base(counterName)
        {
            m_PerMinuteCounterWriter = new PerMinutePerformanceCounterWriter(counterName, true);
        }

        protected override PerformanceCounterWriter PerformanceCounterWriter
        {
            get { return m_PerMinuteCounterWriter; }
        }

        public override void RuntimeInitialize(MethodBase method)
        {
            base.RuntimeInitialize(method);
            ValuesPerMinuteTrackers.AssertTrackerExists(m_CounterName);
        }
    }

    internal static class AttachedPerformanceCounters
    {
        private static readonly Dictionary<string, PerformanceCounter> s_PerformanceCounters = new Dictionary<string, PerformanceCounter>();

        public static PerformanceCounter Get(string category, string categoryHelp, string instance, PerformanceCounterDescription description)
        {
            lock (s_PerformanceCounters)
            {
                PerformanceCounter counter;
                if (!s_PerformanceCounters.TryGetValue(description.Name, out counter))
                {
                    var collection = new PerformanceCounterCollection();
                    counter = collection.AddCounter(category, categoryHelp, description.Name, instance, description.Help, description.Type, description.IsMultiInstance, description.IsReadOnly);
                    collection.Attach();
                    s_PerformanceCounters[description.Name] = counter;
                }
                return counter;
            }
        }
    }

    internal static class ValuesPerMinuteTrackers
    {
        private static readonly Dictionary<string, ValuesPerIntervalTracker> s_ValuePerMinuteTrackers = new Dictionary<string, ValuesPerIntervalTracker>();

        public static void AssertTrackerExists(string counterName)
        {
            lock (s_ValuePerMinuteTrackers)
            {
                if (!s_ValuePerMinuteTrackers.ContainsKey(counterName))
                {
                    s_ValuePerMinuteTrackers[counterName] = new ValuesPerIntervalTracker(TimeSpan.FromMinutes(1));
                }
            }
        }

        public static ValuesPerIntervalTracker Get(string counterName)
        {
            lock (s_ValuePerMinuteTrackers)
            {
                return s_ValuePerMinuteTrackers[counterName];
            }
        }
    }

    internal static class TypeExtension
    {
        public static MemberInfo GetFieldFromType(this Type source, string memberName)
        {
            var memberInfos = source.FindMembers(MemberTypes.Property | MemberTypes.Field, BindingFlags.Instance | BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public,
                                                     (mi, obj) => mi.Name == memberName, null);
            return memberInfos.FirstOrDefault();

        }
    }

    internal class ValuesPerIntervalTracker
    {
        readonly TimeSpan m_Interval;
        readonly Queue<Measurement> m_Measurements = new Queue<Measurement>();

        public long CurrentValue
        {
            get
            {
                RemoveOldValues(DateTime.Now - m_Interval);
                lock (m_Measurements)
                {
                    return m_Measurements.Sum(m => m.Amount);
                }
            }
        }

        public ValuesPerIntervalTracker(TimeSpan interval)
        {
            m_Interval = interval;
        }

        public virtual void ValuesProcessed(long amount)
        {
            var now = DateTime.Now;
            RemoveOldValues(now - m_Interval);
            lock (m_Measurements)
            {
                m_Measurements.Enqueue(new Measurement(now, amount));
            }
        }

        void RemoveOldValues(DateTime now)
        {
            lock (m_Measurements)
            {
                while (m_Measurements.Count > 0 && m_Measurements.Peek().Timestamp < now)
                {
                    m_Measurements.Dequeue();
                }
            }
        }

        private class Measurement
        {
            public DateTime Timestamp { get; private set; }
            public long Amount { get; private set; }

            public Measurement(DateTime timestamp, long amount)
            {
                Timestamp = timestamp;
                Amount = amount;
            }
        }
    }
}


