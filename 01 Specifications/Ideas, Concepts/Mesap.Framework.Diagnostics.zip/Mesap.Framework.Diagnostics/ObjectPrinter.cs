﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Mesap.Framework.Diagnostics
{
    public interface ITypePrinter
    {
        Type Type { get; }
        void Print(object instance, StringBuilder sb, int depth);
    }

    public class ObjectPrinter
    {
        readonly int m_MaxDepth;
        static readonly HashSet<Type> s_SimpleTypes = new HashSet<Type>
                                                          {
                                                              typeof(string),
                                                              typeof(CultureInfo),
                                                              typeof(DateTime),
                                                              typeof(DateTimeOffset)
                                                          };

        readonly List<ITypePrinter> m_TypePrinters = new List<ITypePrinter>();

        public ObjectPrinter(int maxDepth, params ITypePrinter[] typePrinters)
        {
            m_MaxDepth = maxDepth;
            if (typePrinters != null)
            {
                m_TypePrinters.AddRange(typePrinters);
            }
        }

        public string PrintProperties(object instance, string name = null, int depth = 0)
        {
            var sb = new StringBuilder();
            try
            {
                Print(instance, name ?? instance.GetType().Name, sb, depth);
            }
            catch (Exception)
            {
                sb.Append(instance?.GetType().Name ?? "null");
            }
            return sb.ToString();
        }

        void Print(object instance, string propertyName, StringBuilder sb, int depth)
        {
            sb.AppendFormat("{0}{1}=", GetIndention(depth), propertyName);

            if (instance == null)
            {
                sb.AppendLine(string.Empty);
                return;
            }

            var properties = TypeDescriptor.GetProperties(instance);
            var instanceType = instance.GetType();
            if (depth <= m_MaxDepth && IsComplexObject(properties, instanceType))
            {
                var typePrinter = m_TypePrinters.Find(p => p.Type.IsAssignableFrom(instanceType));
                if (typePrinter != null)
                {
                    typePrinter.Print(instance, sb, depth);
                    sb.AppendLine();
                }
                else
                {
                    sb.AppendLine();
                    foreach (PropertyDescriptor property in properties)
                    {
                        var value = property.GetValue(instance);
                        Print(value, property.Name, sb, depth + 1);
                    }
                }
            }
            else
            {
                sb.Append(instance);
                sb.AppendLine();
            }
        }

        static bool IsComplexObject(PropertyDescriptorCollection properties, Type type)
        {
            return !s_SimpleTypes.Contains(type) && properties.Count > 0;
        }

        static string GetIndention(int depth)
        {
            return new string(Enumerable.Repeat(' ', depth * 2).ToArray());
        }
    }
}
