﻿using System;
using System.Diagnostics;
using System.Reflection;
using PostSharp.Aspects;
using PostSharp.Aspects.Configuration;
using PostSharp.Extensibility;

namespace Mesap.Framework.Diagnostics
{
    [Serializable]
    [DebuggerNonUserCode]
    //[ProvideAspectRole(StandardRoles.ExceptionHandling)]
    //[AspectTypeDependency(AspectDependencyAction.Commute, typeof(AutoTraceAttribute))]
    //[AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [MulticastAttributeUsage(MulticastTargets.Method | MulticastTargets.InstanceConstructor | MulticastTargets.StaticConstructor, Inheritance = MulticastInheritance.None)]
    [AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Constructor | AttributeTargets.Property, AllowMultiple = true)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 20)]
    public class AutoLogExceptionAttribute : OnExceptionAspect
    {
        protected Type m_TypeOnAspect;

        public override bool CompileTimeValidate(MethodBase method)
        {
            m_TypeOnAspect = method.DeclaringType;
            return base.CompileTimeValidate(method);
        }

        public sealed override void OnException(MethodExecutionArgs args)
        {
            try
            {
                Log log = null;
                try
                {
                    log = GetLog(args);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex);
                }
                if (log == null)
                {
                    log = new Log(m_TypeOnAspect);
                }
                log.LogExceptionAspectError(args.Exception, "Unhandled exception.");
            }
            catch (Exception ex)
            {
                Log<AutoLogExceptionAttribute> log = new Log<AutoLogExceptionAttribute>();
                log.Error(ex, "Unexpected error. Please contact your Administrator");
            }
            args.FlowBehavior = FlowBehavior.RethrowException;
        }

        protected virtual Log GetLog(MethodExecutionArgs args)
        {
            return new Log(m_TypeOnAspect); 
        }
    }
}
