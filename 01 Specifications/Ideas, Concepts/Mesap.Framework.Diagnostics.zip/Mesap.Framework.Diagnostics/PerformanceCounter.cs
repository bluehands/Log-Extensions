﻿using System;
using System.Diagnostics;

namespace Mesap.Framework.Diagnostics
{
    public class PerformanceCounter : IDisposable
    {
        private System.Diagnostics.PerformanceCounter m_InnerPerformanceCounter;

        public string InstanceName { get; private set; }
        public bool IsMultiInstance { get; private set; }
        public string CategoryHelp { get; private set; }
        public string Category { get; private set; }
        public string Name { get; private set; }
        public string Help { get; private set; }
        public PerformanceCounterType Type { get; private set; }
        
        private bool m_IsDisposed;
        private readonly bool m_IsReadOnly;
        private CounterSample m_LastCounterSample = CounterSample.Empty;
        private int m_NumberOfFailedAccesses;
        private const int c_MaxFailedAccess = 5;

        internal PerformanceCounter(string category, string categoryHelp, string name, string instanceName, string help, PerformanceCounterType type, bool isMultiInstance, bool isReadOnly)
        {
            Category = category ?? string.Empty;
            CategoryHelp = categoryHelp ?? string.Empty;
            InstanceName = instanceName ?? string.Empty;
            Name = name ?? string.Empty;
            Help = help ?? string.Empty;
            Type = type;
            IsMultiInstance = isMultiInstance;
            m_IsReadOnly = isReadOnly;
        }

        public void Dispose()
        {
            m_IsDisposed = true;
            if (m_InnerPerformanceCounter != null)
            {
                m_InnerPerformanceCounter.Dispose();
                m_InnerPerformanceCounter = null;
            }
        }

        internal bool Attach()
        {
            if (m_IsDisposed)
            {
                throw new ObjectDisposedException("PerformanceCounter");
            }
            m_InnerPerformanceCounter = new System.Diagnostics.PerformanceCounter(Category, Name, InstanceName, m_IsReadOnly);
            return true;
        }

        public bool IsValid
        {
            get
            {
                return (m_InnerPerformanceCounter != null);
            }
        }

        public long RawValue
        {
            get
            {
                return InnerPerformanceCounterAccess(() => m_InnerPerformanceCounter.RawValue, long.MinValue);
            }
            set
            {
                InnerPerformanceCounterAccess(() => m_InnerPerformanceCounter.RawValue = value, long.MinValue);
            }
        }

        public long Decrement()
        {
            return InnerPerformanceCounterAccess(() => m_InnerPerformanceCounter.Decrement(), long.MinValue);
        }

        public long Increment()
        {
            return InnerPerformanceCounterAccess(() => m_InnerPerformanceCounter.Increment(), long.MinValue);
        }

        public long IncrementBy(int value)
        {
            return InnerPerformanceCounterAccess(() => m_InnerPerformanceCounter.IncrementBy(value), long.MinValue);
        }

        public float NextValue()
        {
            return InnerPerformanceCounterAccess(() => m_InnerPerformanceCounter.NextValue(), float.MinValue);
        }

        public float NextSample()
        {
            return InnerPerformanceCounterAccess(() => {
                                                         var oSample = m_InnerPerformanceCounter.NextSample();
                                                         var fRetVal = CounterSample.Calculate(m_LastCounterSample, oSample);
                                                         m_LastCounterSample = oSample;
                                                         return fRetVal;
                                                       }, float.MinValue);
        }

        private T InnerPerformanceCounterAccess<T>(Func<T> counterOperation, T failReturnValue) where T : struct
        {
            if (IsValid)
            {
                try
                {
                    var returnValue = counterOperation();
                    m_NumberOfFailedAccesses = 0;
                    return returnValue;
                }
                catch (OverflowException)
                {
                    try
                    {
                        m_InnerPerformanceCounter.RawValue = 0;
                        m_NumberOfFailedAccesses = 0;
                        return default(T);
                    }
                    catch (Exception err)
                    {
                        HandlerInnerPerformanceCounterFailedAccess(err);
                    }
                }
                catch (Exception err)
                {
                    HandlerInnerPerformanceCounterFailedAccess(err);
                }
            }
            return failReturnValue;
        }

        private void HandlerInnerPerformanceCounterFailedAccess(Exception err)
        {
            ++m_NumberOfFailedAccesses;
            var log = new Log<PerformanceCounter>();
            log.Warning(err, "Failed to access performance counter {0}.{1}", InstanceName, Name);
            if (m_NumberOfFailedAccesses >= c_MaxFailedAccess && m_InnerPerformanceCounter != null)
            {
                m_InnerPerformanceCounter.Dispose();
                m_InnerPerformanceCounter = null;
                log.Warning("Disabling performance counter {0}.{1} (accessing counter failed {2} times)", InstanceName, Name, m_NumberOfFailedAccesses);
            }
        }
    }
}