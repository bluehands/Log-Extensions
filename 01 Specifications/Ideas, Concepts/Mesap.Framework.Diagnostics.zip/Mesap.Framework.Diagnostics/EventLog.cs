﻿using System;
using System.Diagnostics;

namespace Mesap.Framework.Diagnostics
{
    public class EventLog
    {
        readonly System.Diagnostics.EventLog m_EventLog;
        readonly Log<EventLog> m_Log = new Log<EventLog>();

        public EventLog(System.Diagnostics.EventLog eventLog)
        {
            if (eventLog == null)
            {
                m_Log.Debug("Event log instance is null. No event log entries will be written.");
            }
            m_EventLog = eventLog;
        }

        public void Invoke(Action<System.Diagnostics.EventLog> action)
        {
            try
            {
                if (m_EventLog != null)
                {
                    action(m_EventLog);
                }
            }
            catch (Exception e)
            {
                m_Log.Error("Event log action failed", e);
            }
        }

        public void Error(string message)
        {
            Invoke(log => log.WriteEntry(message, EventLogEntryType.Error));
        }

        public void Warning(string message)
        {
            Invoke(log => log.WriteEntry(message, EventLogEntryType.Warning));
        }

        public void Info(string message)
        {
            Invoke(log => log.WriteEntry(message, EventLogEntryType.Information));
        }
    }
}
