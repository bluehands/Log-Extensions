﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

namespace Mesap.Framework.Diagnostics
{
    public class PerformanceCounterCollection : IDisposable
    {
        private readonly Dictionary<string, SMPCCategory> m_CounterCollection = new Dictionary<string, SMPCCategory>();
        private bool m_IsDisposed;

        public void Dispose()
        {
            m_IsDisposed = true;
            foreach (SMPCCategory category in m_CounterCollection.Values)
            {
                category.Dispose();
            }
            m_CounterCollection.Clear();
        }

        public PerformanceCounter AddCounter(string categoryName, string categoryHelp, string counterName, string instanceName, string counterHelp, PerformanceCounterType type, bool isMultiInstance, bool isReadOnly)
        {
            if (m_IsDisposed)
            {
                throw new ObjectDisposedException("PerformanceCounterCollection");
            }
            SMPCCategory currentCategory;
            m_CounterCollection.TryGetValue(categoryName.ToLower(), out currentCategory);
            if (currentCategory == null)
            {
                currentCategory = new SMPCCategory(categoryName, categoryHelp, isMultiInstance);
                m_CounterCollection[categoryName.ToLower()] = currentCategory;
            }
            var oCounter = new PerformanceCounter(categoryName, categoryHelp, counterName, instanceName, counterHelp, type, isMultiInstance, isReadOnly);
            currentCategory.Add(oCounter);
            return oCounter;
        }

        public PerformanceCounter AddCounter(string categoryName, string counterName, string instanceName, PerformanceCounterType type, bool autoAttach, bool isReadOnly)
        {
            var oCounter = AddCounter(categoryName, "", counterName, instanceName, "", type, false, isReadOnly);
            oCounter.Attach();
            return oCounter;
        }

        public PerformanceCounter GetCounter(string categoryName, string counterName, string instanceName)
        {
            if (m_IsDisposed)
            {
                throw new ObjectDisposedException("PerformanceCounterCollection");
            }
            PerformanceCounter oCounter = null;
            SMPCCategory oCurrentList;
            m_CounterCollection.TryGetValue(categoryName.ToLower(), out oCurrentList);
            if (oCurrentList != null)
            {
                oCounter = oCurrentList.GetCounter(counterName, instanceName);
            }
            return oCounter;
        }

        public bool Create()
        {
            if (m_IsDisposed)
            {
                throw new ObjectDisposedException("PerformanceCounterCollection");
            }
            foreach (SMPCCategory category in m_CounterCollection.Values)
            {
                category.Create();
            }
            return true;
        }

        public bool Delete()
        {
            if (m_IsDisposed)
            {
                throw new ObjectDisposedException("PerformanceCounterCollection");
            }
            foreach (SMPCCategory category in m_CounterCollection.Values)
            {
                category.Delete();
            }
            return true;
        }

        public bool Attach()
        {
            if (m_IsDisposed)
            {
                throw new ObjectDisposedException("PerformanceCounterCollection");
            }
            foreach (SMPCCategory category in m_CounterCollection.Values)
            {
                category.Attach();
            }
            return true;
        }

        public bool CategoryExists(string categoryName)
        {
            return PerformanceCounterCategory.Exists(categoryName);
        }

        public bool CounterExists(string categoryName, string counterName)
        {
            return PerformanceCounterCategory.CounterExists(counterName, categoryName);
        }

        public bool DeleteCategory(string categoryName)
        {
            return SMPCCategory.Delete(categoryName);
        }

        public IEnumerator GetEnumerator()
        {
            return m_CounterCollection.Values.GetEnumerator();
        }

        public List<PerformanceCounter> ClonedValues
        {
            get
            {
                var aCounters = new List<PerformanceCounter>();
                foreach (SMPCCategory category in m_CounterCollection.Values)
                {
                    aCounters.AddRange(category.ClonedValues);
                }
                return aCounters;
            }
        }
    }
}
