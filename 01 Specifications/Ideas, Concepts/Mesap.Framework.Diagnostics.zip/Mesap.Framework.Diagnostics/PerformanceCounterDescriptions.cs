using System;
using System.Collections.Generic;
using System.Linq;

namespace Mesap.Framework.Diagnostics
{
    public class PerformanceCounterDescription
    {
        public string Name { get; set; }
        public string Help { get; set; }
        public PerformanceCounterType Type { get; set; }
        public bool IsMultiInstance { get; set; }
        public bool IsReadOnly { get; set; }
    }

    public abstract class PerformanceCounterDescriptions
    {
        private readonly Log<PerformanceCounterDescriptions> m_Log = new Log<PerformanceCounterDescriptions>();

        protected Dictionary<string, PerformanceCounterDescription> m_CounterDescriptions = new Dictionary<string, PerformanceCounterDescription>();
        public IEnumerable<PerformanceCounterDescription> Descriptions { get { return m_CounterDescriptions.Values; } }

        public string Category { get; protected set; }
        public string CategoryHelp { get; protected set; }
        public string Instance { get; protected set; }

        public bool TryGetDescription(string name, out PerformanceCounterDescription counterDescription)
        {
            return m_CounterDescriptions.TryGetValue(name, out counterDescription);
        }

        /// <summary>
        /// Creates an instance of <see cref="Mesap.Framework.Diagnostics.PerformanceCounter"/> for each description in Descriptions. Attaches the created performance counters
        /// to a windows performance counter if the category already exists.
        /// </summary>
        /// <returns>A <see cref="Mesap.Framework.Diagnostics.PerformanceCounter"/> mapped by the counter name. The Counters are created and returned always, even on 
        /// initialization errors</returns>
        public Dictionary<string, PerformanceCounter> Create()
        {
            var countersByName = new Dictionary<string, PerformanceCounter>();
            var collection = new PerformanceCounterCollection();
            foreach (var description in Descriptions)
            {
                countersByName[description.Name] = 
                    collection.AddCounter(Category, CategoryHelp, description.Name,
                                      Instance, description.Help, description.Type, description.IsMultiInstance, description.IsReadOnly);
            }

            if (collection.CategoryExists(Category))
            {
                 if (collection.Attach())
                 {
                     foreach (var performanceCounter in countersByName.Values)
                     {
                         performanceCounter.RawValue = 0;
                     }
                 }
                 else
                 {
                     m_Log.Error("Could not initialize windows performance counters for category {0} and instance {1}.", Category, Instance);
                 }
            }
            else
            {
                m_Log.Error("Windows performance counter category {0} does not exist.", Category);
            } 


            return countersByName;
        }

        public void Install()
        {
            try
            {
                var collection = new PerformanceCounterCollection();
                var installationNeeded = !collection.CategoryExists(Category) || Descriptions.Any(description => !collection.CounterExists(Category, description.Name));

                if (installationNeeded)
                {
                    collection.DeleteCategory(Category);

                    foreach (var description in Descriptions)
                    {
                        collection.AddCounter(Category, CategoryHelp, description.Name,
                                              Instance, description.Help, description.Type, description.IsMultiInstance, description.IsReadOnly);
                    }

                    collection.Create();
                }
            }
            catch (Exception e)
            {
                m_Log.Error(e, "Failed to install performance counters for category {0}", Category);
            }
        }

        public void Uninstall()
        {
            try
            {
                var collection = new PerformanceCounterCollection();

                if (collection.CategoryExists(Category))
                {
                    foreach (var description in Descriptions)
                    {
                        collection.AddCounter(Category, CategoryHelp, description.Name,
                                              Instance, description.Help, description.Type, description.IsMultiInstance, description.IsReadOnly);
                    }

                    collection.Delete();
                }
            }
            catch (Exception e)
            {
                m_Log.Error(e, "Failed to install performance counters for category {0}", Category);
            }
        }
    }
}