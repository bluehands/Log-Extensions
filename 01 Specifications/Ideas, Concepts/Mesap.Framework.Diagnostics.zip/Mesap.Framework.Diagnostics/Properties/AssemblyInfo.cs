﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Allgemeine Informationen über eine Assembly werden über die folgenden 
// Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die mit einer Assembly verknüpft sind.
[assembly: AssemblyTitle("Mesap.Framework.Diagnostics")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

// Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly unsichtbar 
// für COM-Komponenten. Wenn Sie auf einen Typ in dieser Assembly von 
// COM zugreifen müssen, legen Sie das ComVisible-Attribut für diesen Typ auf "true" fest.
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
// Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt für COM verfügbar gemacht wird
[assembly: Guid("2f4c5a29-bd0a-4e51-b89b-b779c5b8d1ee")]

[assembly: InternalsVisibleTo("Mesap.Framework.Core, PublicKey=0024000004800000940000000602000000240000525341310004000001000100abed50c614b9aed57edcc5fd8d18a555872f70c69254519e868415bef36e998b44cece2928e46a4abaa7c19f18087750f516a8908e702afe09411d053c90606a4338edac37086c93e5d59e1b22f4ebf2cacdd96fb7d2485beb9d18b2c46d7ce243d80f6722a78166b4cbbb901fa13c9ed8efe3300309de9fbf83af50b3c7dc83")]
[assembly: InternalsVisibleTo("Mesap.Framework.Diagnostics.Test, PublicKey=0024000004800000940000000602000000240000525341310004000001000100abed50c614b9aed57edcc5fd8d18a555872f70c69254519e868415bef36e998b44cece2928e46a4abaa7c19f18087750f516a8908e702afe09411d053c90606a4338edac37086c93e5d59e1b22f4ebf2cacdd96fb7d2485beb9d18b2c46d7ce243d80f6722a78166b4cbbb901fa13c9ed8efe3300309de9fbf83af50b3c7dc83")]
[assembly: InternalsVisibleTo("Mesap.Framework.Core.Test, PublicKey=0024000004800000940000000602000000240000525341310004000001000100abed50c614b9aed57edcc5fd8d18a555872f70c69254519e868415bef36e998b44cece2928e46a4abaa7c19f18087750f516a8908e702afe09411d053c90606a4338edac37086c93e5d59e1b22f4ebf2cacdd96fb7d2485beb9d18b2c46d7ce243d80f6722a78166b4cbbb901fa13c9ed8efe3300309de9fbf83af50b3c7dc83")]
