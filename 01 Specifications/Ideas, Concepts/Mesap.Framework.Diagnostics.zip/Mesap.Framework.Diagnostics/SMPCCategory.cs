﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Mesap.Framework.Diagnostics
{
    internal class SMPCCategory : IDisposable
    {
        private readonly Dictionary<string, PerformanceCounter> m_Counters = new Dictionary<string, PerformanceCounter>();
        private readonly bool m_IsMultiInstance = true;
        private readonly string m_Name = "";
        private readonly string m_Help = "";

        internal SMPCCategory()
        {
        }

        internal SMPCCategory(string name, string help, bool isMultiInstance)
        {
            m_Name = name;
            m_Help = help;
            m_IsMultiInstance = isMultiInstance;
        }

        public void Dispose()
        {
            foreach (PerformanceCounter counter in m_Counters.Values)
            {
                counter.Dispose();
            }
            m_Counters.Clear();
        }

        public bool Create()
        {
            if (!PerformanceCounterCategory.Exists(m_Name))
            {
                var ccdc = new CounterCreationDataCollection();
                var names = new Dictionary<string, bool>();
                foreach (PerformanceCounter counter in m_Counters.Values)
                {
                    if (!names.ContainsKey(counter.Name.ToLower()))
                    {
                        Console.WriteLine(@"Creating Counter '" + counter.Name + @"' ...");
                        var counterCreationData = new CounterCreationData();
                        var type = (System.Diagnostics.PerformanceCounterType)Enum.Parse(typeof(System.Diagnostics.PerformanceCounterType), counter.Type.ToString());
                        counterCreationData.CounterType = type;
                        counterCreationData.CounterName = counter.Name;
                        counterCreationData.CounterHelp = counter.Help;
                        names.Add(counter.Name.ToLower(), true);
                        ccdc.Add(counterCreationData);
                    }
                }
                PerformanceCounterCategoryType categoryType = PerformanceCounterCategoryType.SingleInstance;
                if (m_IsMultiInstance)
                {
                    categoryType = PerformanceCounterCategoryType.MultiInstance;
                }
                PerformanceCounterCategory.Create(m_Name, m_Help, categoryType, ccdc);
            }
            return true;
        }

        public bool Delete()
        {
            return Delete(m_Name);
        }

        internal static bool Delete(string categoryName)
        {
            if (PerformanceCounterCategory.Exists(categoryName))
            {
                PerformanceCounterCategory.Delete(categoryName);
                return true;
            }
            return false;
        }

        public bool Attach()
        {
            if (PerformanceCounterCategory.Exists(m_Name))
            {
                foreach (PerformanceCounter counter in m_Counters.Values)
                {
                    counter.Attach();
                }
                return false;
            }
            return false;
        }

        public void Add(PerformanceCounter counter)
        {
            if (counter != null)
            {
                string sKey = counter.Name + "_" + counter.InstanceName;
                sKey = sKey.ToLower();
                m_Counters[sKey] = counter;
            }
        }

        public PerformanceCounter GetCounter(string counterName, string instanceName)
        {
            PerformanceCounter counter;
            string sKey = counterName + "_" + instanceName;
            sKey = sKey.ToLower();
            m_Counters.TryGetValue(sKey, out counter);
            return counter;
        }

        internal List<PerformanceCounter> ClonedValues
        {
            get
            {
                var aList = new PerformanceCounter[m_Counters.Count];
                m_Counters.Values.CopyTo(aList, 0);
                var aRetVal = new List<PerformanceCounter>();
                aRetVal.AddRange(aList);
                return aRetVal;
            }
        }
    }
}
