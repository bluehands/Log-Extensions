﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using Mesap.Framework.Diagnostics.Internal;
using PostSharp.Aspects;
using PostSharp.Aspects.Configuration;
using PostSharp.Extensibility;
using PostSharp.Reflection;

namespace Mesap.Framework.Diagnostics
{
    [Serializable]
    //[DebuggerNonUserCode]  //<-- Comment out this, to enable debugging
//    [ProvideAspectRole(StandardRoles.Tracing)]
//    [AspectTypeDependency(AspectDependencyAction.Commute, typeof(AutoLogExceptionAttribute))]
//    [AspectRoleDependency(AspectDependencyAction.Commute, StandardRoles.PerformanceInstrumentation)]
    [MulticastAttributeUsage(MulticastTargets.Method | MulticastTargets.InstanceConstructor | MulticastTargets.StaticConstructor, Inheritance = MulticastInheritance.None)]
    [AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Method | AttributeTargets.Constructor, AllowMultiple = true)]
    [OnMethodBoundaryAspectConfiguration(AspectPriority = 10)]
    public class AutoTraceAttribute : OnMethodBoundaryAspect
    {
        [Serializable]
        [DebuggerNonUserCode]
        private abstract class LogFactory
        {
            [Serializable]
            [DebuggerNonUserCode]
            private class LogFactoryFromLog : LogFactory
            {
                internal LogFactoryFromLog(MethodBase method, LocationInfo member)
                    : base(method, member)
                {
                }

                protected sealed override Log CreateLog(object instance, Arguments args)
                {
                    return m_Member.GetValue(instance) as Log;
                }
            }
            [Serializable]
            [DebuggerNonUserCode]
            private class LogFactoryFromUnknown : LogFactory
            {
                internal LogFactoryFromUnknown(MethodBase method, LocationInfo member)
                    : base(method, member)
                {
                }

                protected sealed override Log CreateLog(object instance, Arguments args)
                {
                    Log log = new Log(m_TypeOnAspect);
                    return log;
                }
            }

            private readonly Type m_TypeOnAspect;
            private readonly LocationInfo m_Member;
            [NonSerialized]
            private Log m_InternalLog;

            private LogFactory(MethodBase method, LocationInfo member)
            {
                m_Member = member;
                m_TypeOnAspect = method.DeclaringType;
            }
            public static LogFactory Create(MethodBase method)
            {
                Type typeOnAspect = method.DeclaringType;
                LocationInfo member = typeOnAspect.GetLocationFromType<Log>();
                if (member != null)
                {
                    if (!member.LocationType.ContainsGenericParameters)
                    {
                        return new LogFactoryFromLog(method, member);
                    }
                }
                return new LogFactoryFromUnknown(method, null);
            }
            public Log GetLog(object instance, Arguments args)
            {
                if (m_InternalLog == null)
                {
                    if (instance == null)
                    {
                        m_InternalLog = new Log(m_TypeOnAspect);
                    }
                    else
                    {
                        m_InternalLog = CreateLog(instance, args);
                    }
                }
                return m_InternalLog;
            }
            public Log GetLog()
            {
                return m_InternalLog;
            }
            protected abstract Log CreateLog(object instance, Arguments args);
        }
        protected class TraceAttributeStackTrace : StackTrace
        {
            private readonly MethodBase m_MethodBase;

            public TraceAttributeStackTrace(MethodBase methodBase)
            {
                m_MethodBase = methodBase;
            }

            public override StackFrame GetFrame(int index)
            {
                return new TraceAttributeStackFrame(m_MethodBase);
            }
            public override int FrameCount
            {
                get
                {
                    return 1;
                }
            }
            public override StackFrame[] GetFrames()
            {
                return new StackFrame[] {new TraceAttributeStackFrame(m_MethodBase)};
            }
        }
        protected class TraceAttributeStackFrame : StackFrame
        {
            private readonly MethodBase m_MethodBase;

            public TraceAttributeStackFrame(MethodBase methodBase)
            {
                m_MethodBase = methodBase;
            }

            public override int GetFileColumnNumber()
            {
                return 0;
            }
            public override int GetFileLineNumber()
            {
                return 0;
            }
            public override string GetFileName()
            {
                return string.Empty;
            }
            public override int GetILOffset()
            {
                return 0;
            }
            public override int GetNativeOffset()
            {
                return 0;
            }
            public override MethodBase GetMethod()
            {
                return m_MethodBase;
            }
        }

        private readonly string m_Message;
        [NonSerialized]
        private TraceAttributeStackTrace m_StackTrace;
        [NonSerialized]
        private static readonly Stopwatch s_StopWatch = Stopwatch.StartNew();
        private LogFactory m_Factory;

        public AutoTraceAttribute()
        {

        }
        public AutoTraceAttribute(string message)
        {
            m_Message = message;
        }

        public override bool CompileTimeValidate(MethodBase method)
        {
            if (method.MemberType == MemberTypes.Property)
            {
                return false;
            }
            string methodName = method.Name;
            if (methodName.StartsWith("get_") || methodName.StartsWith("set_"))
            {
                return false;
            }
            if (method.GetCustomAttributes(typeof(CompilerGeneratedAttribute), false).Length > 0)
            {
                return false;
            }
            if (method.IsStatic)
            {
                Message.Write(SeverityType.Warning, "TA001", string.Format("{0}:{1} is excluded from tracing, because it is static. Please use [Trace(AttributeExclude = true)] or make the method non static.", method.DeclaringType.Name, method.Name));
                return false;
            }
            FieldInfo logMember = method.DeclaringType.GetFieldFromType<Log>();
            if (logMember != null)
            {
                LocationInfo logLocationInfo = new LocationInfo(logMember);
                if (logLocationInfo.LocationType.ContainsGenericParameters)
                {
                    Message.Write(SeverityType.Warning, "TA002", string.Format("Type {0} contains a log from a type with generic parameters. This log cannot be reused, and the method is excluded from tracing.", method.DeclaringType.Name));
                    return false;
                }
            }
            if (method.DeclaringType!=null && method.DeclaringType.ContainsGenericParameters)
            {
                Message.Write(SeverityType.Warning, "TA003", string.Format("Type {0} contains a log from a type with generic parameters. This log cannot be reused, , and the method is excluded from tracing.", method.DeclaringType.Name));
                return false;
            }
            return base.CompileTimeValidate(method);
        }
        public sealed override void CompileTimeInitialize(MethodBase method, AspectInfo aspectInfo)
        {
            base.CompileTimeInitialize(method, aspectInfo);
            CreateLogOnCompileTime(method);
        }
        
        public sealed override void RuntimeInitialize(MethodBase method)
        {
            try
            {
                base.RuntimeInitialize(method);
                m_StackTrace = new TraceAttributeStackTrace(method);
            }
            catch (Exception ex)
            {
                Log<AutoTraceAttribute> log = new Log<AutoTraceAttribute>();
                log.Error("Unexpected error. Please contact your Administrator", ex);
            }
        }

        public sealed override void OnEntry(MethodExecutionArgs args)
        {
            try
            {
                Log log = GetLog(args.Instance, args.Arguments);
                if (log != null)
                {
                    args.MethodExecutionTag = s_StopWatch.Elapsed;
                    log.TraceAspectEnter(m_StackTrace, m_Message);
                }
            }
            catch (Exception ex)
            {
                Log<AutoTraceAttribute> log = new Log<AutoTraceAttribute>();
                log.Error("Unexpected error. Please contact your Administrator", ex);
            }
        }
        public sealed override void OnExit(MethodExecutionArgs args)
        {
            try
            {
                Log log = GetLog();
                if (log != null)
                {
                    var tag = args.MethodExecutionTag;
                    if (tag != null)
                    {
                        var begin = (TimeSpan)tag;
                        var end = s_StopWatch.Elapsed - begin;
                        log.TraceAspectExit(m_StackTrace, m_Message, end);
                    }
                }
            }
            catch (Exception ex)
            {
                Log<AutoTraceAttribute> log = new Log<AutoTraceAttribute>();
                log.Error("Unexpected error. Please contact your Administrator", ex);
            }
        }

        protected virtual void CreateLogOnCompileTime(MethodBase method)
        {
            m_Factory = LogFactory.Create(method);
        }
        protected virtual Log GetLog(object instance, Arguments args)
        {
            return m_Factory.GetLog(instance, args);
        }
        protected virtual Log GetLog()
        {
            return m_Factory.GetLog();
        }
    }
}
